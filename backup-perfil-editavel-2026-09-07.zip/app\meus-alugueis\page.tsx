﻿"use client"
import { useState } from "react"

export default function MeusAlugueis() {
  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 mb-6">Meus Aluguéis</h1>
        
        {/* CARDS DE ATIVIDADES */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="p-6 rounded-xl bg-blue-50 border-2 border-blue-200">
            <p className="text-sm text-blue-700 mb-1">Aluguéis Realizados</p>
            <p className="text-3xl font-bold text-blue-700">12</p>
          </div>
          <div className="p-6 rounded-xl bg-green-50 border-2 border-green-200">
            <p className="text-sm text-green-700 mb-1">Avaliação</p>
            <p className="text-3xl font-bold text-green-700">4.9</p>
          </div>
          <div className="p-6 rounded-xl bg-purple-50 border-2 border-purple-200">
            <p className="text-sm text-purple-700 mb-1">Aluguéis Ativos</p>
            <p className="text-3xl font-bold text-purple-700">3</p>
          </div>
          <div className="p-6 rounded-xl bg-orange-50 border-2 border-orange-200">
            <p className="text-sm text-orange-700 mb-1">Faturamento</p>
            <p className="text-3xl font-bold text-orange-700">R$ 850</p>
          </div>
        </div>

        {/* LISTA DE ALUGUÉIS */}
        <div className="bg-white p-6 rounded-xl border shadow-sm">
          <h2 className="text-xl font-bold mb-4">Histórico de Aluguéis</h2>
          <p className="text-gray-600">Em breve...</p>
        </div>
      </div>
    </div>
  )
}
