import MessagesPage from "@/components/MessagesPage";

export default function MensagensPage() {
  return <MessagesPage />;
}
