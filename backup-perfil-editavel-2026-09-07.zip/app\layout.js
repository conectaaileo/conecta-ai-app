import TelegramSupport from "@/components/TelegramSupport";
import PwaInstall from "@/components/PwaInstall";
import { Inter } from "next/font/google";
import "./globals.css";
import Header from "@/components/Header";

const inter = Inter({ subsets: ["latin"] });

export const metadata = {
  title: "conectaAI - Aluguel entre Vizinhos",
  description: "Plataforma de aluguel de itens entre vizinhos",
};

export default function RootLayout({ children }) {
  return (
    <html lang="pt-BR">
      <body className={`${inter.className} bg-gray-50 min-h-screen`}>
        <Header />
        <main>{children}</main>
        <footer className="bg-gray-800 text-white py-6 mt-12">
          <div className="container mx-auto px-4 text-center">
            <p>&copy; 2024 conectaAI. Todos os direitos reservados.</p>
          </div>
        </footer>
            <TelegramSupport />
      <PwaInstall />
    </body>
    </html>
  );
}
